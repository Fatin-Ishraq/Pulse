# Pulse

> *"Not a dashboard. An instrument panel."*

A cinematic terminal-based system monitor. Every panel animates. Nothing is static.

## Installation

```bash
pip install -e .
```

## Usage

```bash
pulse
```

## Controls

- `Q` — Quit
- `T` — Toggle theme
