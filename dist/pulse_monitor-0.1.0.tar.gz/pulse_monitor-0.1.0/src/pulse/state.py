from pulse.themes import THEMES

# Every module will import this to stay in sync with the current UI aesthetic
current_theme = THEMES["bridge"]
